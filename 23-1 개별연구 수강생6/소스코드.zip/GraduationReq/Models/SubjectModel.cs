﻿namespace GraduationReq.Models
{
    public class Subject // 과목
    {
        public string subjectCode {  get; set; } // 학수번호
        public string subjectName { get; set; } // 과목명
        public int credit { get; set; } // 학점
        public string year { get; set; } // 개설연도
        public string semester { get; set; } // 개설학기
        public int designCredit { get; set; } // 설계학점
        public bool IsSameSubject(Subject subject)
        {
            return subjectCode.Equals(subject.subjectCode);
        }
    }

    // todo : 기초설계 요소설계 관련 수동 추가해야 함
    public class UserSubject : Subject // 사용자 과목 read
    {
        public string completionDiv { get; set; } // 이수구분
        public string completionDivField { get; set; } // 이수구분영역
        public string engineeringFactor { get; set; } // 공학요소
        public string engineeringFactorDetail { get; set; } // 공학세부요소
        public string english { get; set; } // 원어강의종류
        public string retake { get; set; } // 재수강구분

        public List<string> GetKeyWords()
        {
            UserInfo user = new UserInfo();
            List<string> keywords = new List<string>();

            // 1. 공통교양, 기본소양, MSC/BSM 처리
            if (engineeringFactorDetail == "기초교양(교필)")
            {
                keywords.Add("공통교양");
            }
            if (engineeringFactorDetail == "기본소양")
            {
                keywords.Add("기본소양");
            }
            if (engineeringFactor == "MSC/BSM")
            {
                keywords.Add("MSC/BSM");

                // msc 전체 학점 추가
                if (engineeringFactorDetail == "수학")
                {
                    keywords.Add("수학");
                }
                if (engineeringFactorDetail == "기초과학")
                {
                    string key = subjectName.Contains("실험") ? "과학실험" : "과학";
                    keywords.Add(key);
                }
                if (engineeringFactorDetail == "전산학")
                {
                    keywords.Add("전산학");
                }
            }

            // 2. 전공 과목 처리
            if (engineeringFactor == "전공" || completionDiv == "전공")
            {
                UserInfo userInfo = new UserInfo();
                keywords.Add("전공");

                if (subjectCode.Substring(0, 3).Equals(userInfo.GetMajorSubjectCode()))
                {
                    keywords.Add("주전공");
                    if (completionDivField == "전문")
                    {
                        keywords.Add("주전공전문");
                    }
                }
                // todo : 복수전공 처리
                if (completionDivField == "전문")
                {
                    keywords.Add("전공전문");
                }
                if (completionDiv == "전필")
                {
                    keywords.Add("전공필수");
                }

                if (engineeringFactorDetail == "전공설계")
                {
                    keywords.Add("설계");
                    if (UserInfo.basicDesignSubjects.Select(s => s.subjectCode).Contains(subjectCode))
                        keywords.Add("기초설계");
                    if (UserInfo.elementDesignSubjects.Select(s => s.subjectCode).Contains(subjectCode))
                        keywords.Add("요소설계");
                    if (UserInfo.capstoneDesignSubjects.Select(s => s.subjectCode).Contains(subjectCode))
                        keywords.Add("종합설계");
                }

                // 해당 과목은 이수 구분상 전공필수지만, score_list에 그냥 전공으로 표시됨
                // 예외처리 필요
                if (subjectName.Contains("이산구조") || subjectName.Contains("계산적사고법") || subjectName.Contains("공개SW프로젝트"))
                {
                    keywords.Add("전공필수");
                }
            }

            // 3. 영어 강의 처리
            if (english == "영어")
            {
                keywords.Add("영어강의");
            }

            // 4. 일반 교양 처리
            if (completionDiv == "일교")
            {
                keywords.Add("일반교양");
            }

            return keywords;
        }
    }

    public class DesignSubject : Subject
    {
        // 기초설계, 요소설계, 종합설계
        public string designType { get; set; }
    }

    public class SimilarMajor
    {
        public string currSubjectName { get; set; }
        public int currSubjectStartYear { get; set; }
        public string prevSubjectName { get; set; }
        public int prevSubjectStartYear { get; set; }
        public int prevSubjectEndYear { get; set; }
    }

    public class DiffMajor
    {
        public int startYear { get; set; }
        public int endYear { get; set; }
        public string subjectCode { get; set; }
        public string subjectName { get; set; }
        public string otherMajor { get; set; }
        public string otherSubjectCode { get; set; }
        public string otherSubjectName { get; set; }
    }

}
