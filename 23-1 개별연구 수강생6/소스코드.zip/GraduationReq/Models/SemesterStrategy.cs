﻿using System.Data;
using ExcelDataReader;

namespace GraduationReq.Models
{
    public class SemesterStrategy
    {
        private int semester = 0;
        private bool resultBool = false;
        private string result = "";

        public int getSemester()
        {
            return semester;
        }
        public bool getResultBool()
        {
            return resultBool;
        }

        public string getResult()
        {
            return result;
        }

        private void setResult()
        {
            if (resultBool)
            {
                result = "이수 학기: " + semester + "학기<br/>졸업 요건: 8학기 (충족)";
            }
            else
            {
                result = "이수 학기: " + semester + "학기<br/>졸업 요건: 8학기 (" + (8 - semester) + "학기 부족)";
            }
        }

        public void setSemester(string studentScoreFile)
        {
            var semesters = new HashSet<string>();

            using (var stream = File.Open(studentScoreFile, FileMode.Open, FileAccess.Read))
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    var result = reader.AsDataSet();
                    var table = result.Tables[0]; // 첫 번째 시트를 사용

                    foreach (DataRow row in table.Rows)
                    {
                        if (row[2].ToString().Length == 4) // 여름학기, 겨울학기
                        {
                            continue;
                        }
                        string semester = row[1].ToString() + "-" + row[2].ToString();
                        semesters.Add(semester);
                    }
                }
            }
            this.semester = semesters.Count - 1;

            if (semester >= 8)
                resultBool = true;
            setResult();
        }
    }
}
