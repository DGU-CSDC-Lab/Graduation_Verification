﻿using Microsoft.AspNetCore.DataProtection.KeyManagement;
using MySqlX.XDevAPI.Common;

namespace GraduationReq.Models
{
    public abstract class LanguageStrategy
    {
        public string name { get; set; }
        public string lowerName { get; set; }
        public string score { get; set; }
        public string criteria { get; set; }
        public double ratio { get; set; }
        public bool resultBool { get; set; }
        public string result { get; set; }

        public abstract void CheckRule();
        public void setResultTrue(string name, string score, string criteria)
        {
            this.result = "응시한 시험: " + name + "<br/>시험 점수: " + score + "점<br/>졸업 요건: " + criteria + "점 (충족)";
        }
        public void setResultFalse(string name, string score, string criteria)
        {
            this.result = "응시한 시험: " + name + "<br/>시험 점수: " + score + "점<br/>졸업 요건: " + criteria + "점 (미충족)";
        }
    }

    public class ToeicStrategy : LanguageStrategy
    {
        public ToeicStrategy(string name, string score)
        {
            this.name = "TOEIC";
            this.lowerName = name;
            this.score = score;
            this.criteria = "700";
        }

        public override void CheckRule()
        {
            int iTestScore = Convert.ToInt32(this.score);
            if (iTestScore >= 700)
            {
                Console.WriteLine("{0} 성적: {1} ==> 졸업요건(700점 이상) 충족", this.name, this.score);
                setResultTrue(name, score, criteria);
                this.ratio = 1;
                resultBool = true;
            }
            else
            {
                Console.WriteLine("{0} 성적: {1} ==> 졸업요건(700점 이상) 불충족", this.name, this.score);
                setResultFalse(name, score, criteria);
                this.ratio = iTestScore / 700.0;
                resultBool = false;
            }
        }
    }

    public class ToeflCbtStrategy : LanguageStrategy
    {
        public ToeflCbtStrategy(string name, string score)
        {
            this.name = "TOEFL CBT";
            this.lowerName = name;
            this.score = score;
            this.criteria = "207";
        }

        public override void CheckRule()
        {
            int iTestScore = Convert.ToInt32(this.score);
            if (iTestScore >= 207)
            {
                Console.WriteLine("{0} 성적: {1} ==> 졸업요건(207점 이상) 충족", this.name, this.score);
                setResultTrue(name, score, criteria);
                this.ratio = 1;
                resultBool = true;
            }
            else
            {
                Console.WriteLine("{0} 성적: {1} ==> 졸업요건(207점 이상) 불충족", this.name, this.score);
                setResultFalse(name, score, criteria);
                this.ratio = iTestScore / 207.0;
                resultBool = false;
            }
        }
    }

    public class ToeflIbtStrategy : LanguageStrategy
    {
        public ToeflIbtStrategy(string name, string score)
        {
            this.name = "TOEFL IBT";
            this.lowerName = name;
            this.score = score;
            this.criteria = "76";
        }

        public override void CheckRule()
        {
            int iTestScore = Convert.ToInt32(this.score);
            if (iTestScore >= 76)
            {
                Console.WriteLine("{0} 성적: {1} ==> 졸업요건(76점 이상) 충족", this.name, this.score);
                setResultTrue(name, score, criteria);
                this.ratio = 1;
                resultBool = true;
            }
            else
            {
                Console.WriteLine("{0} 성적: {1} ==> 졸업요건(76점 이상) 불충족", this.name, this.score);
                setResultFalse(name, score, criteria);
                this.ratio = iTestScore / 76.0;
                resultBool = false;
            }
        }
    }

    public class TepsStrategy : LanguageStrategy
    {
        public TepsStrategy(string name, string score)
        {
            this.name = "TEPS";
            this.lowerName = name;
            this.score = score;
            this.criteria = "327";
        }

        public override void CheckRule()
        {
            int iTestScore = Convert.ToInt32(this.score);
            if (iTestScore >= 327)
            {
                Console.WriteLine("{0} 성적: {1} ==> 졸업요건(327점 이상) 충족", this.name, this.score);
                setResultTrue(name, score, criteria);
                this.ratio = 1;
                resultBool = true;
            }
            else
            {
                Console.WriteLine("{0} 성적: {1} ==> 졸업요건(327점 이상) 불충족", this.name, this.score);
                setResultFalse(name, score, criteria);
                this.ratio = iTestScore / 327.0;
                resultBool = false;
            }
        }
    }

    public class ToeicSpeakingStrategy : LanguageStrategy
    {
        public ToeicSpeakingStrategy(string name, string score)
        {
            this.name = "TOEIC Speaking";
            this.lowerName = name;
            this.score = score;
            this.criteria = "140";
        }

        public override void CheckRule()
        {
            int iTestScore = Convert.ToInt32(this.score);
            if (iTestScore >= 140)
            {
                Console.WriteLine("{0} 성적: {1} ==> 졸업요건(140점 이상) 충족", this.name, this.score);
                setResultTrue(name, score, criteria);
                this.ratio = 1;
                resultBool = true;
            }
            else
            {
                Console.WriteLine("{0} 성적: {1} ==> 졸업요건(140점 이상) 불충족", this.name, this.score);
                setResultFalse(name, score, criteria);
                this.ratio = iTestScore / 140.0;
                resultBool = false;
            }
        }
    }

    public class OPIcStrategy : LanguageStrategy
    {
        public OPIcStrategy(string name, string score)
        {
            this.name = "OPIc";
            this.lowerName = name;
            this.score = score;
            this.criteria = "IM 2";
        }

        public override void CheckRule()
        {
            string uTestScore = this.score.ToUpper();
            string rTestScore = uTestScore.Replace(" ", string.Empty);
            this.score = rTestScore;
            switch (rTestScore)
            {
                case "ADVANCEDLOW":
                case "AL":
                case "INTERMEDIATEHIGH":
                case "IH":
                case "INTERMEDIATEMID3":
                case "IM3":
                case "INTERMEDIATEMID2":
                case "IM2":
                    Console.WriteLine("{0} 성적: {1} ==> 졸업요건(IM 2 이상) 충족", this.name, this.score);
                    setResultTrue(name, score, criteria);
                    this.ratio = 1;
                    resultBool = true;
                    break;
                case "INTERMEDIATEMID1":
                case "IM1":
                case "INTERMEDIATELOW":
                case "IL":
                case "NOVICEHIGH":
                case "NH":
                case "NOVICEMID":
                case "NM":
                case "NOVICELOW":
                case "NL":
                default:
                    Console.WriteLine("{0} 성적: {1} ==> 졸업요건(IM 2 이상) 불충족", this.name, this.score);
                    setResultFalse(name, score, criteria);
                    this.ratio = 0.5;
                    resultBool = false;
                    break;
            }
        }
    }

    public class EsolStrategy : LanguageStrategy
    {
        public EsolStrategy(string name, string score)
        {
            this.name = "Cambridge ESOL Examinations";
            this.lowerName = name;
            this.score = score;
            this.criteria = "FCE";
        }

        public override void CheckRule()
        {
            string uTestScore = this.score.ToUpper();
            string rTestScore = uTestScore.Replace(" ", string.Empty);
            this.score = rTestScore;
            switch (rTestScore)
            {
                case "FCE":
                    Console.WriteLine("{0} 성적: {1} ==> 졸업요건(FCE 이상) 충족", this.name, this.score);
                    setResultTrue(name, score, criteria);
                    this.ratio = 1;
                    resultBool = true;
                    break;
                case "PET":
                default:
                    Console.WriteLine("{0} 성적: {1} ==> 졸업요건(FCE 이상) 불충족", this.name, this.score);
                    setResultFalse(name, score, criteria);
                    this.ratio = 0.5;
                    resultBool = false;
                    break;
            }
        }
    }

    public class IeltsStrategy : LanguageStrategy
    {
        public IeltsStrategy(string name, string score)
        {
            this.name = "IELTS";
            this.lowerName = name;
            this.score = score;
            this.criteria = "5.5";
        }

        public override void CheckRule()
        {
            double dTestScore = Convert.ToDouble(this.score);
            if (dTestScore >= 5.5)
            {
                Console.WriteLine("{0} 성적: {1} ==> 졸업요건(5.5점 이상) 충족", this.name, this.score);
                setResultTrue(name, score, criteria);
                this.ratio = 1;
                resultBool = true;
            }
            else
            {
                Console.WriteLine("{0} 성적: {1} ==> 졸업요건(5.5점 이상) 불충족", this.name, this.score);
                setResultFalse(name, score, criteria);
                this.ratio = dTestScore / 5.5;
                resultBool = false;
            }
        }
    }

    public class GtelpStrategy : LanguageStrategy
    {
        public GtelpStrategy(string name, string score)
        {
            this.name = "G-TELP";
            this.lowerName = name;
            this.score = score;
            this.criteria = "LEVEL 64 또는 LEVEL 85";
        }

        public override void CheckRule()
        {
            string sTestScore = this.score[..7].ToUpper().Replace(" ", string.Empty);
            int iTestScore = Convert.ToInt32(this.score[^3..]);
            this.score = sTestScore + " " + iTestScore;
            switch (sTestScore)
            {
                case "LEVEL1":
                    Console.WriteLine("{0} 성적: {1} ==> 졸업요건(LEVEL2 64점 또는 LEVEL3 85점 이상) 충족", this.name, this.score);
                    setResultTrue(name, score, criteria);
                    this.ratio = 1;
                    resultBool = true;
                    break;
                case "LEVEL2":
                    if (iTestScore >= 64)
                    {
                        Console.WriteLine("{0} 성적: {1} ==> 졸업요건(LEVEL2 64점 또는 LEVEL3 85점 이상) 충족", this.name, this.score);
                        setResultTrue(name, score, criteria);
                        this.ratio = 1;
                        resultBool = true;
                    }
                    else
                    {
                        Console.WriteLine("{0} 성적: {1} ==> 졸업요건(LEVEL2 64점 또는 LEVEL3 85점 이상) 불충족", this.name, this.score);
                        setResultFalse(name, score, criteria);
                        this.ratio = 0.5;
                        resultBool = false;
                    }
                    break;
                case "LEVEL3":
                    if (iTestScore >= 85)
                    {
                        Console.WriteLine("{0} 성적: {1} ==> 졸업요건(LEVEL2 64점 또는 LEVEL3 85점 이상) 충족", this.name, this.score);
                        setResultTrue(name, score, criteria);
                        this.ratio = 0.5;
                        resultBool = true;
                    }
                    else
                    {
                        Console.WriteLine("{0} 성적: {1} ==> 졸업요건(LEVEL2 64점 또는 LEVEL3 85점 이상) 불충족", this.name, this.score);
                        setResultFalse(name, score, criteria);
                        this.ratio = 0.5;
                        resultBool = false;
                    }
                    break;
                default:
                    Console.WriteLine("{0} 성적: {1} ==> 졸업요건(LEVEL2 64점 또는 LEVEL3 85점 이상) 불충족", this.name, this.score);
                    setResultFalse(name, score, criteria);
                    this.ratio = 0.5;
                    resultBool = false;
                    break;
            }
        }
    }

    public class NoLanguageStrategy : LanguageStrategy
    {
        public NoLanguageStrategy(string name, string score)
        {
            this.name = name;
            this.score = score;
            this.criteria = "0";
            this.result = "";
        }

        public override void CheckRule()
        {
            Console.WriteLine("외국어 시험 성적 없음");
            this.result = "외국어 시험 성적이 없습니다.";
            this.ratio = 0.1;
            resultBool = false;
        }
    }
}
