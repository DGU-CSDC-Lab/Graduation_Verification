﻿using ExcelDataReader;
using System.Data;

namespace GraduationReq.Models
{
    public class EnglishStrategy
    {
        private int english = 0;
        private List<string> englishList = new List<string>();
        private bool resultBool = false;
        private string result = "";

        public int getEnglish()
        {
            return english;
        }
        public List<string> getEnglishList()
        {
            return englishList;
        }
        public bool getResultBool()
        {
            return resultBool;
        }
        public string getResult()
        {
            return result;
        }

        private void setResult()
        {
            if (resultBool)
            {
                result = "이수 강의: " + english + "개<br/>졸업 요건: 4개 (충족)";
            }
            else
            {
                result = "이수 강의: " + english + "개<br/>졸업 요건: 4개 (" + (4 - english) + "개 부족)";
            }
        }

        public void setEnglish(UserInfo userInfo)
        {

            var keywordSubjectPair = new Dictionary<string, List<UserSubject>>();
            keywordSubjectPair = userInfo.keywordSubjectPair;

            foreach (string key in keywordSubjectPair.Keys)
            {
                if (key == "영어강의")
                {
                    foreach (UserSubject subject in keywordSubjectPair[key])
                    {
                        englishList.Add(subject.subjectName);
                    }
                }
            }

            this.english = englishList.Count;

            if (english >= 4)
                resultBool = true;
            setResult();
        }
    }
}
