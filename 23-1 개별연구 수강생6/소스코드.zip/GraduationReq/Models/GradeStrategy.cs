﻿using ExcelDataReader;
using System.Data;

namespace GraduationReq.Models
{
    public class GradeStrategy
    {
        private double grade = 0;
        private bool resultBool = false;
        private string result = "";

        public double getGrade()
        {
            return grade;
        }
        public bool getResultBool()
        {
            return resultBool;
        }

        public string getResult()
        {
            return result;
        }

        private void setResult()
        {
            if (resultBool)
            {
                result = "평점 평균: " + grade + "점<br/>졸업 요건: 2.0점 (충족)";
            }
            else
            {
                result = "평점 평균: " + grade + "점<br/>졸업 요건: 2.0점 (" + (2.0 - grade) + "점 부족)";
            }
        }

        public void setGrade(string studentScoreFile)
        {
            double creditSum = 0;
            double gradeSum = 0;

            using (var stream = File.Open(studentScoreFile, FileMode.Open, FileAccess.Read))
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    var result = reader.AsDataSet();
                    var table = result.Tables[0]; // 첫 번째 시트를 사용

                    bool flag = false;
                    foreach (DataRow row in table.Rows)
                    {
                        if (!flag)
                        {
                            flag = true;
                            continue;
                        }
                        double credit = Convert.ToDouble(row[9]);
                        string sGrade = row[10].ToString();
                        double dGrade = 0;
                        switch (sGrade)
                        {
                            case "A+":
                                dGrade = 4.5;
                                break;
                            case "A0":
                                dGrade = 4.0;
                                break;
                            case "B+":
                                dGrade = 3.5;
                                break;
                            case "B0":
                                dGrade = 3.0;
                                break;
                            case "C+":
                                dGrade = 2.5;
                                break;
                            case "C0":
                                dGrade = 2.0;
                                break;
                            case "D+":
                                dGrade = 1.5;
                                break;
                            case "D0":
                                dGrade = 1.0;
                                break;
                            case "F":
                                if (credit == 1) // 보통 1학점은 P/F 과목
                                {
                                    credit = 0;
                                }
                                else
                                {
                                    dGrade = 0.0;
                                }
                                break;
                            case "P":
                                credit = 0;
                                break;

                        }
                        creditSum += credit;
                        gradeSum += dGrade * credit;
                    }
                }
            }
            this.grade = Math.Round(gradeSum / creditSum, 2);

            if (grade >= 2.0)
                resultBool = true;
            setResult();
        }
    }
}
