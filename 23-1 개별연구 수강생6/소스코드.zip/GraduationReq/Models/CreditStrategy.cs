﻿using ExcelDataReader;
using System.Data;

namespace GraduationReq.Models
{
    public class CreditStrategy
    {
        private double credit = 0;
        private double majorCredit = 0;     // 전공
        private double majorExpCredit = 0;  // 전공 전문
        private double commonGeneral = 0;   // 공통 교양
        private double basicGeneral = 0;    // 일반 교양
        private double scholarBasic = 0;    // 학문 기초
        private bool resultBool = false;
        private string result = "";

        public double getCredit()
        {
            return credit;
        }
        public double getMajorCredit()
        {
            return majorCredit;
        }
        public double getMajorExpCredit()
        {
            return majorExpCredit;
        }
        public double getCommonGeneral()
        {
            return commonGeneral;
        }
        public double getBasicGeneral()
        {
            return basicGeneral;
        }
        public double getScholarBasic()
        {
            return scholarBasic;
        }
        public bool getResultBool()
        {
            return resultBool;
        }

        public string getResult()
        {
            return result;
        }

        private void setResult()
        {
            if (resultBool)
            {
                result = "취득 학점: " + credit + "학점<br/>졸업 요건: 140학점 (충족)";
            }
            else
            {
                result = "취득 학점: " + credit + "학점<br/>졸업 요건: 140학점 (" + (140 - credit) + "학점 부족)";
            }
        }

        public void setCredit(string studentScoreFile)
        {
            double credit = 0;
            double majorCredit = 0;
            double majorExpCredit = 0;
            double commonGeneral = 0;
            double basicGeneral = 0;
            double scholarBasic = 0;

            using (var stream = File.Open(studentScoreFile, FileMode.Open, FileAccess.Read))
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    var result = reader.AsDataSet();
                    var table = result.Tables[0]; // 첫 번째 시트를 사용

                    bool flag = false;
                    foreach (DataRow row in table.Rows)
                    {
                        if (!flag)
                        {
                            flag = true;
                            continue;
                        }
                        credit += Convert.ToDouble(row[9]);
                        if (Convert.ToString(row[3]).Equals("전공") || Convert.ToString(row[3]).Equals("전필"))
                        {
                            majorCredit += Convert.ToDouble(row[9]);
                            if (Convert.ToString(row[4]).Equals("전문"))
                            {
                                majorExpCredit += Convert.ToDouble(row[9]);
                            }
                        }
                        if (Convert.ToString(row[3]).Equals("공교"))
                        {
                            commonGeneral += Convert.ToDouble(row[9]);
                        }
                        if (Convert.ToString(row[3]).Equals("일교"))
                        {
                            basicGeneral += Convert.ToDouble(row[9]);
                        }
                        if (Convert.ToString(row[3]).Equals("학기"))
                        {
                            scholarBasic += Convert.ToDouble(row[9]);
                        }
                    }
                }
            }
            this.credit = credit;
            this.majorCredit = majorCredit;
            this.majorExpCredit = majorExpCredit;
            this.commonGeneral = commonGeneral;
            this.basicGeneral = basicGeneral;
            this.scholarBasic = scholarBasic;

            if (credit >= 140)
                resultBool = true;
            setResult();
        }
    }
}
