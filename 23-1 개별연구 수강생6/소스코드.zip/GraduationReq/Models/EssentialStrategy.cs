﻿using ExcelDataReader;
using System.Data;

namespace GraduationReq.Models
{
    public class EssentialStrategy
    {
        private int essential = 0;
        private Dictionary<string, List<string>> essentialList = new Dictionary<string, List<string>>();
        private double ratio = 0;
        private bool resultBool = false;
        private string result = "";

        public int getEssential()
        {
            return essential;
        }
        public Dictionary<string, List<string>> getEssentialList()
        {
            return essentialList;
        }
        public double getRatio()
        {
            return ratio;
        }
        public bool getResultBool()
        {
            return resultBool;
        }
        public string getResult()
        {
            return result;
        }

        private void setResult()
        {
            if (resultBool)
            {
                result = "필수 강의 모두 이수(충족)";
            }
            else
            {
                result = "미이수한 필수 강의: " + essential + "개";
            }
        }

        public void setEssential(List<List<Rule>> Total_rule, string studentScoreFile)
        {
            int requiredCount = 0;

            foreach (Rule rule in Total_rule[0])
            {
                int ruleNumber = Convert.ToInt32(rule.sequenceNumber);
                if (ruleNumber - 5 == 1)
                {
                    essentialList["공통교양"] = rule.neededSubjects;
                    requiredCount += 8;
                }
                else if (ruleNumber - 5 == 3)
                {
                    essentialList["기본소양"] = rule.neededSubjects;
                    requiredCount += 3;
                }
                else if (ruleNumber - 5 == 5)
                {
                    essentialList["MSC/BSM"] = rule.neededSubjects;
                    requiredCount += 3;
                }
                else if (ruleNumber - 5 == 12)
                {
                    essentialList["전공"] = rule.neededSubjects;
                    requiredCount += 9;
                }
            }

            Console.WriteLine("<미이수한 필수 강의>");
            foreach (string key in essentialList.Keys)
            {
                foreach (string s in essentialList[key])
                {
                    Console.WriteLine("[{0}] {1}", key, s);
                }
            }

            int leadershipCount = 0;
            foreach (var item in essentialList["공통교양"])
            {
                if (item.EndsWith("리더십"))
                {
                    leadershipCount++;
                }
            }
            if (leadershipCount == 2)
            {
                essentialList["공통교양"].RemoveAll(sub => sub.EndsWith("리더십"));
            }

            List<string> majorList = new List<string> (essentialList["전공"]);
            List<string> commonGenList = new List<string>(essentialList["공통교양"]);

            using (var stream = File.Open(studentScoreFile, FileMode.Open, FileAccess.Read))
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    var result = reader.AsDataSet();
                    var table = result.Tables[0]; // 첫 번째 시트를 사용

                    foreach (DataRow row in table.Rows)
                    {
                        foreach (var subject in majorList)
                        {
                            if (row[7].ToString().Equals(subject))
                            {
                                essentialList["전공"].Remove(subject);
                            }
                        }
                        foreach (var subject in commonGenList)
                        {
                            if (row[7].ToString().Equals(subject))
                            {
                                essentialList["공통교양"].Remove(subject);
                            }
                        }
                        if (essentialList["전공"].Count == 0 && essentialList["공통교양"].Count == 0)
                        {
                            break;
                        }
                    }
                }
            }

            this.essential = essentialList["공통교양"].Count + essentialList["기본소양"].Count + essentialList["MSC/BSM"].Count + essentialList["전공"].Count;
            this.ratio = 1 - (double)essential / requiredCount;
            if (essential == 0)
                resultBool = true;
            setResult();
        }
    }
}
