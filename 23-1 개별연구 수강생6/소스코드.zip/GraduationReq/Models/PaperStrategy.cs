﻿namespace GraduationReq.Models
{
    public class PaperStrategy
    {
        private int paper = 0;
        private List<string> paperList = new List<string>();
        private bool resultBool = false;
        private string result = "";

        public int getPaper()
        {
            return paper;
        }
        public List<string> getList()
        {
            return paperList;
        }
        public bool getResultBool()
        {
            return resultBool;
        }
        public string getResult()
        {
            return result;
;
        }

        private void setResult()
        {
            if (resultBool)
            {
                result = "졸업논문 완료";
            }
            else
            {
                result = "졸업논문 미완료";
            }
        }

        public void setPaperList(List<List<Rule>> Total_rule)
        {
            foreach (Rule rule in Total_rule[0])
            {
                int ruleNumber = Convert.ToInt32(rule.sequenceNumber);
                if (ruleNumber - 5 == 17)
                {
                    paperList = rule.neededSubjects;
                }
            }
            paper = paperList.Count;

            if (paper == 0)
                resultBool = true;
            setResult();
        }
    }
}
