﻿namespace GraduationReq.Models
{
    public class NewStrategy
    {
        public SemesterStrategy semesterStrategy { get; set; }
        public CreditStrategy creditStrategy { get; set; }
        public GradeStrategy gradeStrategy { get; set; }
        public LanguageStrategy languageStrategy { get; set; }
        public EnglishStrategy englishStrategy { get; set; }
        public EssentialStrategy essentialStrategy { get; set; }
        public PaperStrategy paperStrategy { get; set; }
    }
}
