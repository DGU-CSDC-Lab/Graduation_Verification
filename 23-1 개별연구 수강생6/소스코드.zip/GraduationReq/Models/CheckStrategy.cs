﻿namespace GraduationReq.Models
{
    public abstract class CheckStrategy
    {
        public Rule rule { get; set; }
        public UserInfo userInfo { get; set; }
        public Dictionary<string, List<UserSubject>> userSubjectPair { get; set; }
        public Dictionary<string, int> userCreditPair { get; set; }
        public string errMessage { get; set; }

        public abstract bool CheckRule();
    }

    public class NumberValueChecker : CheckStrategy
    {
        public double userValue { get; set; }
        public double requiredValue { get; set; }

        public NumberValueChecker(UserInfo userInfo)
        {
            this.userSubjectPair = userInfo.keywordSubjectPair;
            this.userCreditPair = userInfo.keywordCreditPair;
            this.userInfo = userInfo;
        }

        public override bool CheckRule()
        {
            // 1. rule에서 keyword 추출
            string keyword = rule.keyword;

            // 2. keyword를 바탕으로 학점과 숫자 입력값 저장
            userValue = Convert.ToDouble(userCreditPair[keyword]);
            requiredValue = Convert.ToDouble(rule.singleInput);

            // 3. '종합설계 이수를 위해 필요한 설계 이수학점을 입력하시오'
            // 위의 rule의 경우, keyword가 종합설계로 추출되는데, 이러면 종합설계의 학점이 추출되므로 
            // rule이 맞지 않는다. 그래서, 새로운 키워드를 부여하여 새롭게 학점을 계산한다.
            if (rule.question.Contains("필요") && rule.question.Contains("종합설계"))
            {
                keyword = "[종합설계이수]";
                userValue = userCreditPair["기초설계"] + userCreditPair["요소설계"];
            }

            if (userValue < requiredValue)
            {
                string errorMessage = String.Format("[{0}] 수강학점: {1}, 졸업요건: {2}학점 ({1}/{2}) 필요학점: {3}학점",
                                                    keyword, userValue, requiredValue, requiredValue - userValue);
                rule.SetResultMessage(errorMessage);
                return false;
            }
            else
            {
                string successMessage = String.Format("[{0}] 수강학점: {1}, 졸업요건: {2}학점",
                                                      keyword, userValue, requiredValue);
                rule.SetResultMessage(successMessage);
                return true;
            }
        }
    }

    public class OXValueChecker : CheckStrategy
    {
        public string userOX;
        public OXValueChecker(UserInfo userInfo)
        {
            this.userSubjectPair = userInfo.keywordSubjectPair;
            this.userCreditPair = userInfo.keywordCreditPair;
            // OX 룰 관련해서는 userInfo 구조 어떻게 쓸지?
            // dictionary[keyword] 형태로 다시 만들지
            // 기존처럼 영어PASS:O 이런 데이터 하드코딩해서 쓸지..
            // OX 룰은 '구분'이 교양, 전공에는 없고 졸업요건 룰부터 있음
            this.userInfo = userInfo;
        }

        public override bool CheckRule()
        {
            // todo : temp value
            userOX = "X";
            string condition = rule.singleInput; // O or X
            if ("X".Equals(condition.ToUpper()))
                return true;
            return condition.ToUpper().Equals(userOX.ToUpper());
        }

        public void SetUserOX()
        {
            // todo
        }
    }

    public class MultiValueChecker : CheckStrategy
    {
        public int matches { get; set; }
        public int Matches
        {
            get
            {
                return matches;
            }
        }
        public int requiredCount { get; set; }
        public int RequiredCount
        {
            get
            {
                return requiredCount;
            }
        }
        public int requiredCredit { get; set; }
        public int RequiredCredit
        {
            get
            {
                return requiredCredit;
            }
        }
        public MultiValueChecker(UserInfo userInfo)
        {
            this.userSubjectPair = userInfo.keywordSubjectPair;
            this.userCreditPair = userInfo.keywordCreditPair;

            requiredCount = 0;
            requiredCredit = 0;
        }

        public override bool CheckRule()
        {
            matches = 0;
            int takenCredit = 0;

            // 1. rule의 keyword 추출
            string keyword = rule.keyword;

            // if(String.IsNullOrEmpty(keyword)) {
            //   keyword = "공통교양";
            // }

            // 2. 해당 keyword에 대하여, User가 들은 과목 + rule에 포함되는 과목 추출
            List<UserSubject> userSubjects = new List<UserSubject>();
            userSubjects = userSubjectPair[keyword];
            List<Subject> requiredSubjects = rule.requiredSubjects;

            // 3. 만약, rule이 필수 이수 과목에 대해서 checking하는 거면,
            // 해당 과목들의 수와 학점을 정확히 저장해야 한다.
            if (rule.shouldTakeAll)
            {
                requiredCount = requiredSubjects.Count;
                foreach (Subject subject in requiredSubjects)
                {
                    requiredCredit += subject.credit;
                }
            }

            // 수강한 과목
            List<string> takenSubjects = new List<string>();
            // 수강이 필요한 과목
            List<string> neededSubjects = requiredSubjects.Select(subject => subject.subjectName).ToList<string>();

            foreach (Subject reqSubject in requiredSubjects)
            {
                foreach (UserSubject userSubject in userSubjects)
                {
                    // 5. User가 들은 과목과 Rule이 요구하는 과목 중에서 학수번호가 일치하면,
                    // 매칭 과목수, 수강 학점, 수강한 과목, 수강이 필요한 과목을 갱신한다.
                    if (reqSubject.IsSameSubject(userSubject))
                    {
                        matches += 1;
                        takenCredit += userSubject.credit;
                        neededSubjects.Remove(userSubject.subjectName);
                        takenSubjects.Add(userSubject.subjectName);
                        break;
                    }
                }
            }

            // 6. 수강한 과목을 ,을 기준으로 연결
            string takenSubjectsString = String.Join<string>(", ", takenSubjects);

            // 7. 이제 각 기준에 맞게, rule의 통과 여부 판정
            if (!rule.shouldTakeAll)
            {
                // 선택 과목 입력 룰의 경우, Pass or Fail을 표시하지 않음
                string resultMessage = String.Format("[{0}] 수강과목수: {1}", keyword, matches);
                if (takenSubjects.Count > 0)
                    resultMessage += String.Format("[수강한 과목] {0}", takenSubjectsString);
                rule.SetResultMessage(resultMessage);
                rule.SetNeededSubject(neededSubjects);
                rule.SetMatches(matches);
                rule.SetRequiredCount(requiredCount);
                return false;
            }
            else if (matches < requiredCount || takenCredit < requiredCredit)
            {
                string errMessage = String.Format("[{0}] 수강과목수: {1}, 졸업요건: {2}과목 ({1}/{2}), 필요 과목수: {3} ",
                                                  keyword, matches, requiredCount, requiredCount - matches);
                string neededSubjectsString = String.Join<string>(", ", neededSubjects);
                errMessage += String.Format("[필요과목]: {0}", neededSubjectsString);

                rule.SetResultMessage(errMessage);
                rule.SetNeededSubject(neededSubjects);
                rule.SetMatches(matches);
                rule.SetRequiredCount(requiredCount);
                return false;
            }
            else
            {
                string successMessage = String.Format("[{0}] 수강과목수: {1}, 졸업요건: {2}과목 ",
                                                      keyword, matches, requiredCount);
                if (takenSubjects.Count > 0)
                    successMessage += String.Format("[수강한 과목] {0}", takenSubjectsString);
                rule.SetResultMessage(successMessage);
                rule.SetNeededSubject(neededSubjects);
                rule.SetMatches(matches);
                rule.SetRequiredCount(requiredCount);
                return true;
            }
        }
    }

    public class NoCheckStrategy : CheckStrategy
    {
        public override bool CheckRule()
        {
            return false;
        }
    }
}
