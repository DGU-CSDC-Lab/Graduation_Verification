﻿using Graduation2.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Net.Http.Headers;
using Microsoft.Extensions.Logging;
using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using ExcelDataReader;

namespace Graduation2.Controllers
{
    public class ResultController : Controller
    {
        // private readonly ILogger<HomeController> _logger;
        
        private IWebHostEnvironment environment;
        public ResultController(IWebHostEnvironment environment)
        {
            this.environment = environment;
        }

        // public HomeController(ILogger<HomeController> logger)
        // {
        //     _logger = logger;
        // }
        public bool IsValidRule(Rule rule)
        {
          if(rule.division == "교양" || rule.division == "전공")
            return true;
          else
            return false;
          // if(Convert.ToInt32(newRule.sequenceNumber) > 23 || Convert.ToInt32(newRule.sequenceNumber) < 6)
          //    return false;
          // else
          //   return true;
        }
        public IActionResult Index()
        {
            string enrollmentYear = "";
            string major = "";

            List<List<Rule>> Total_rule = new List<List<Rule>>();

            // 한글 인코딩
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            string baseFilePath = this.environment.WebRootPath;

            // string inputFile = Path.Combine(baseFilePath, "upload",fileNames[0]);

            // 1. User 정보 입력
            string gradeFile = Path.Combine(baseFilePath, "user", "total_score.xlsx");
            UserInfo userInfo = new UserInfo();
            userInfo.GetUserSubject(gradeFile);

            // 2. 주전공 졸업 사정 기준 입력
            //string templateFilePath = Path.Combine(baseFilePath, "templates", "template_2016CSE.xlsx");
            //string Major_template = Path.Combine(baseFilePath, "templates", "template_2017CSE.xlsx");
            string Major_template = Path.Combine(baseFilePath, "templates", "double_major.xlsx");

            // 3. 주전공 template pasing
            List<Rule> major_rules = new List<Rule>();
            using (var stream = System.IO.File.Open(Major_template, System.IO.FileMode.Open, System.IO.FileAccess.Read))
            {
                using(var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    int currentRuleNum = 0;
                    int currentSheetNum = 1;
                    List<int> multiInputRuleNumber = new List<int>();
                    string ruleDivision = "";

                    // template의 첫 줄 날리기
                    reader.Read();

                    // line by line 읽으면서 rule 생성하기
                    while(reader.Read())
                    {
                        string[] valueArray = new string[6]; // 모두 string임에 주의
                        
                        for(int i = 0; i < 6; i++)
                        {
                            if (reader.GetValue(i) == null)
                                valueArray[i] = "";
                            else
                                valueArray[i] = reader.GetValue(i).ToString();
                        }
                        
                        // 구분이 공백인 경우를 위해서 공백이 아닐때를 저장해놓고 이용함
                        if(valueArray[0] == "" || valueArray[0] == null)
                          valueArray[0] = ruleDivision;
                        else
                          ruleDivision = valueArray[0];

                        // 0. 구분 // 1. 일련번호 // 2. 질문 // 3. 입력 // 4. 응답유형 // 5.비고

                        // -- Rule Generator --
                        // 입력받은 정보를 바탕으로 1~5번까지를 rule에 기록함
                        RuleBuilder ruleBuilder = new RuleBuilder();
                        Rule newRule = ruleBuilder.SetDivision(ruleDivision)
                                                  .SetSequenceNumber(valueArray[1])
                                                  .SetQuestion(valueArray[2])
                                                  .SetSingleInput(valueArray[3])
                                                  .SetReplyType(valueArray[4])
                                                  .SetIsMaJorRule(true)
                                                  .Build();

                        // -- Rule에 기재될 Rule checking strategy 생성 --
                        CheckStrategy checkStrategy = null;

                        if(!IsValidRule(newRule))   // 기초정보, 졸업요건, 예외적용의 경우 strategy를 만들지 않는다 --> keyword 추출 실패
                          checkStrategy = new NoCheckStrategy();
                        else {  // 교양, 전공의 경우 응답 유형에 맞춰서 알맞은 strategy를 생성한다
                          switch(newRule.replyType)
                          {
                            case "단수":
                              checkStrategy = new NumberValueChecker(userInfo);
                              break;
                            case "OX":
                              checkStrategy = new OXValueChecker(userInfo);
                              break;
                            case "목록":
                              checkStrategy = new MultiValueChecker(userInfo);
                              break;
                            default:
                              checkStrategy = new NoCheckStrategy();
                              break;
                          }
                        }
                        // 생성한 strategy를 해당 rule의 일부로 등록한다
                        newRule.SetCheckStrategy(checkStrategy);

                        // 만약, 응답유형이 목록이라면, 현재 rule에 대해 추가적인 Sheet처리가 필요하다
                        // 추후, 해당 rule에 Sheet에서 추출한 subject를 requiredSubject에 추가하게 된다
                        if(valueArray[4] == "목록")
                        {
                            multiInputRuleNumber.Add(currentRuleNum);
                        }

                        // 기초정보를 바탕으로 rule name 생성
                        // 이 파트는 왜 만든거지..?
                        if(newRule.division == "기초정보")
                        {
                          if (newRule.question.Contains("입학년도"))
                            enrollmentYear = newRule.singleInput;
                          else if (newRule.question.Contains("학과"))
                            major = newRule.singleInput;
                        }

                        // 실제 Rule 저장
                        major_rules.Add(newRule);
                        currentRuleNum++;
                    }

                    // 이제 sheet를 옮겨가며, 
                    // multipleInuptRuleNumber에 기재된 rule(응답유형이 '목록')의 requiredsubject를 추가하는 과정
                    while(reader.NextResult()) 
                    {
                      List<Subject> newSubjects = new List<Subject>();
                      currentSheetNum++;
                      reader.Read();reader.Read();
                      
                      while(reader.Read())
                      {
                        // 교양 columns --> 0. NO. // 1. 학수번호 // 2. 과목명 // 3. 학점 // 4. 개설년도
                        // 전공 columns --> 0. NO. // 1. 학수번호 // 2. 과목명 // 3. 학점 // 4. 설계학점 // 5. 개설년도
                        // 대체 columns --> 복잡복잡 

                        int cols = reader.FieldCount;

                        string[] valueArray = new string[cols];
                        for(int i = 0 ; i < cols ; i++)
                        {
                            if (reader.GetValue(i) == null)
                                valueArray[i] = "";
                            else
                                valueArray[i] = Regex.Replace(reader.GetValue(i).ToString(), @"\s", ""); // 과목명 내 띄어쓰기 제거
                        }

                        // 학수번호가 기재가 안되어 있으면, 다음 과목을 받아온다
                        if (String.IsNullOrEmpty(valueArray[1])) break;
                        
                        // 대체 인정 Sheet를 제외한 모든 Sheet에서 subject를 추출한다
                        // 이거 조건이 잘못됨 --> 현재 line by line 검사를하고 있기 때문에, 대체 인정 결국에는 해당 과정을 포함함
                        if(!(valueArray[0].Contains("예시"))) 
                        {
                            Subject newSubject = new Subject{
                              subjectCode = valueArray[1],
                              subjectName = valueArray[2],
                              credit = Convert.ToInt32(valueArray[3].Trim()),
                              year = valueArray[4].Trim()
                            };

                            // 이때, 현재 sheet가 전공(+설계)인 경우, 
                            //개설년도가 5번 인덱스이므로, year를 change한다 
                            if(cols == 6) 
                            {
                              newSubject.year = valueArray[cols-1];
                            }
                            newSubjects.Add(newSubject);
                        }
                      }
                      
                      // 현재 sheet의 모든 subject가 추출되었다면,
                      // 해당 rule의 requiredsubject를 subjects로 갱신해준다 
                      int ruleIdx = multiInputRuleNumber[currentSheetNum-2];
                      major_rules[ruleIdx].requiredSubjects = newSubjects;
                    }
                }
            }

            // 4. 만들어진 모든 주전공 rule에 대하여, 이제 check를 진행하여 isPassed를 갱신한다
            foreach (Rule rule in major_rules)
            {
                rule.CheckRule();
            }
            Total_rule.Add(major_rules);

            // 5. 복수전공 template 파싱
            if (userInfo.GetDobuleMajorStatus().Equals("Y"))
            {
                string Minor_template = Path.Combine(baseFilePath, "templates", "Real.xlsx");

                List<Rule> minor_rules = new List<Rule>();
                using (var stream = System.IO.File.Open(Minor_template, System.IO.FileMode.Open, System.IO.FileAccess.Read))
                {
                    using (var reader = ExcelReaderFactory.CreateReader(stream))
                    {
                        int currentRuleNum = 0;
                        int currentSheetNum = 1;
                        List<int> multiInputRuleNumber = new List<int>();
                        string ruleDivision = "";

                        // template의 첫 줄 날리기
                        reader.Read();

                        // line by line 읽으면서 rule 생성하기
                        while (reader.Read())
                        {
                            string[] valueArray = new string[6]; // 모두 string임에 주의

                            for (int i = 0; i < 6; i++)
                            {
                                if (reader.GetValue(i) == null)
                                    valueArray[i] = "";
                                else
                                    valueArray[i] = reader.GetValue(i).ToString();
                            }

                            if (valueArray[1] == "") break;

                            // 구분이 공백인 경우를 위해서 공백이 아닐때를 저장해놓고 이용함
                            if (valueArray[0] == "" || valueArray[0] == null)
                                valueArray[0] = ruleDivision;
                            else
                                ruleDivision = valueArray[0];

                            // 0. 구분 // 1. 일련번호 // 2. 질문 // 3. 입력 // 4. 응답유형 // 5.비고

                            // -- Rule Generator --
                            // 입력받은 정보를 바탕으로 0~5번까지를 rule에 기록함
                            RuleBuilder ruleBuilder = new RuleBuilder();
                            Rule newRule = ruleBuilder.SetDivision(ruleDivision)
                                                      .SetSequenceNumber(valueArray[1])
                                                      .SetQuestion(valueArray[2])
                                                      .SetSingleInput(valueArray[3])
                                                      .SetReplyType(valueArray[4]) 
                                                      .SetIsMaJorRule(false)
                                                      .Build();

                            // -- Rule에 기재될 Rule checking strategy 생성 --
                            CheckStrategy checkStrategy = null;

                            if (!IsValidRule(newRule))   // 기초정보, 졸업요건, 예외적용의 경우 strategy를 만들지 않는다 --> keyword 추출 실패
                                checkStrategy = new NoCheckStrategy();
                            else
                            {  // 교양, 전공의 경우 응답 유형에 맞춰서 알맞은 strategy를 생성한다
                                switch (newRule.replyType)
                                {
                                    case "단수":
                                        checkStrategy = new NumberValueChecker(userInfo);
                                        break;
                                    case "OX":
                                        checkStrategy = new OXValueChecker(userInfo);
                                        break;
                                    case "목록":
                                        checkStrategy = new MultiValueChecker(userInfo);
                                        break;
                                    default:
                                        checkStrategy = new NoCheckStrategy();
                                        break;
                                }
                            }
                            // 생성한 strategy를 해당 rule의 일부로 등록한다
                            newRule.SetCheckStrategy(checkStrategy);

                            // 만약, 응답유형이 목록이라면, 현재 rule에 대해 추가적인 Sheet처리가 필요하다
                            // 추후, 해당 rule에 Sheet에서 추출한 subject를 requiredSubject에 추가하게 된다
                            if (valueArray[4] == "목록")
                            {
                                multiInputRuleNumber.Add(currentRuleNum);
                            }

                            // 기초정보를 바탕으로 rule name 생성
                            // 이 파트는 왜 만든거지..?
                            if (newRule.division == "기초정보")
                            {
                                if (newRule.question.Contains("입학년도"))
                                    enrollmentYear = newRule.singleInput;
                                else if (newRule.question.Contains("학과"))
                                    major = newRule.singleInput;
                            }

                            // 실제 Rule 저장
                            minor_rules.Add(newRule);
                            currentRuleNum++;
                        }

                        // 이제 sheet를 옮겨가며, 
                        // multipleInuptRuleNumber에 기재된 rule(응답유형이 '목록')의 requiredsubject를 추가하는 과정
                        while (reader.NextResult())
                        {
                            List<Subject> newSubjects = new List<Subject>();
                            currentSheetNum++;
                            reader.Read(); reader.Read();

                            while (reader.Read())
                            {
                                // 교양 columns --> 0. NO. // 1. 학수번호 // 2. 과목명 // 3. 학점 // 4. 개설년도
                                // 전공 columns --> 0. NO. // 1. 학수번호 // 2. 과목명 // 3. 학점 // 4. 설계학점 // 5. 개설년도
                                // 대체 columns --> 복잡복잡 

                                int cols = reader.FieldCount;

                                string[] valueArray = new string[cols];
                                for (int i = 0; i < cols; i++)
                                {
                                    if (reader.GetValue(i) == null)
                                        valueArray[i] = "";
                                    else
                                        valueArray[i] = Regex.Replace(reader.GetValue(i).ToString(), @"\s", ""); // 과목명 내 띄어쓰기 제거
                                }

                                // 학수번호가 기재가 안되어 있으면, 다음 과목을 받아온다
                                if (String.IsNullOrEmpty(valueArray[1])) break;

                                // 대체 인정 Sheet를 제외한 모든 Sheet에서 subject를 추출한다
                                // 이거 조건이 잘못됨 --> 현재 line by line 검사를하고 있기 때문에, 대체 인정 결국에는 해당 과정을 포함함
                                if (!(valueArray[0].Contains("예시")))
                                {
                                    Subject newSubject = new Subject
                                    {
                                        subjectCode = valueArray[1],
                                        subjectName = valueArray[2],
                                        credit = Convert.ToInt32(valueArray[3].Trim()),
                                        year = valueArray[4].Trim()
                                    };

                                    // 이때, 현재 sheet가 전공(+설계)인 경우, 
                                    //개설년도가 5번 인덱스이므로, year를 change한다 
                                    if (cols == 6)
                                    {
                                        newSubject.year = valueArray[cols - 1];
                                    }
                                    newSubjects.Add(newSubject);
                                }
                            }

                            // 현재 sheet의 모든 subject가 추출되었다면,
                            // 해당 rule의 requiredsubject를 subjects로 갱신해준다 
                            int ruleIdx = multiInputRuleNumber[currentSheetNum - 2];
                            minor_rules[ruleIdx].requiredSubjects = newSubjects;
                        }
                    }
                }

                foreach (Rule rule in minor_rules)
                {
                    rule.CheckRule();
                }
                Total_rule.Add(minor_rules);
            }

            // 최종 rule과 user 정보를 담아서 View로 화면에 그리게 된다
            var result = new Tuple<UserInfo, List<List<Rule>>>(userInfo, Total_rule) {};
            return View(result);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
